"""
Device-aware task generation.
Applies hardware latency scaling + thermal degradation to base task profiles.
"""
import copy
import math
import random
import numpy as np
from models.task import Task, make_task, MODEL_PROFILES
from utils.device_profiles import DEVICE_PROFILES


# Per-model memory-boundedness coefficient (0=compute-bound, 1=memory-bound)
# Memory-bound models are penalised more on low-bandwidth devices (RPi5)
MODEL_MEM_BOUND = {
    "YOLOv5n":    0.35,   # mostly compute
    "MobileNetV2":0.25,
    "WhisperTiny":0.60,   # attention layers are memory-heavy
    "DistilBERT": 0.65,
    "MiDaS":      0.40,
}

# Reference bandwidth (i7-1165G7 DDR4-3200 dual channel)
REF_BW_GBPS = 51.2


def device_latency_scale(model_name: str, device: dict) -> float:
    """
    Compute effective latency scale for a model on a device.
    Combines:
      1. Base compute scale (freq ratio)
      2. Memory bandwidth penalty for memory-bound models
      3. Thermal throttling factor
    """
    base  = device["latency_scale"]
    mem_b = MODEL_MEM_BOUND.get(model_name, 0.4)

    # Memory bandwidth ratio adjustment
    bw_ratio = REF_BW_GBPS / device["mem_bw_gbps"]
    mem_adj  = 1.0 + mem_b * (bw_ratio - 1.0) * 0.5   # partial effect

    # Thermal throttling (sustained load degrades performance)
    thermal  = 1.0 / device["thermal_factor"]

    return base * mem_adj * thermal


def make_device_task(task_id: int, model_name: str, arrival_time: float,
                     device_name: str, noise_pct: float = 0.08,
                     rng: random.Random = None) -> Task:
    """Create a task with device-calibrated latency."""
    if rng is None:
        rng = random
    device = DEVICE_PROFILES[device_name]
    scale  = device_latency_scale(model_name, device)

    prof   = MODEL_PROFILES[model_name]
    noise  = 1.0 + rng.gauss(0, noise_pct)
    lat    = max(5.0, prof["latency_ms"] * scale * noise)

    return Task(
        task_id      = task_id,
        model_name   = model_name,
        priority     = prof["priority"],
        latency_ms   = lat,
        energy_mj    = prof["energy_mj"] * scale,   # energy scales with compute time
        deadline_ms  = prof["deadline_ms"],
        arrival_time = arrival_time,
        decay_fn     = prof["decay_fn"],
        staleness_drop = prof["staleness_drop"],
    )


def synthetic_uniform_device(n_tasks: int = 600, seed: int = 42,
                              device_name: str = "RPi5"):
    rng    = random.Random(seed)
    models = list(MODEL_PROFILES.keys())
    tasks  = []
    t      = 0.0
    for i in range(n_tasks):
        model = rng.choice(models)
        tasks.append(make_device_task(i, model, t, device_name, rng=rng))
        t += rng.expovariate(1 / 0.05)
    return tasks


def robot_pipeline_device(duration_s: float = 30.0, seed: int = 42,
                           device_name: str = "RPi5"):
    rng     = random.Random(seed)
    streams = {
        "YOLOv5n":    1 / 0.1,
        "MiDaS":      1 / 0.15,
        "MobileNetV2":1 / 0.3,
        "WhisperTiny":1 / 3.0,
        "DistilBERT": 1 / 2.0,
    }
    tasks = []
    tid   = 0
    for model, rate in streams.items():
        t = rng.expovariate(rate)
        while t < duration_s:
            tasks.append(make_device_task(tid, model, t, device_name, rng=rng))
            tid += 1
            t  += rng.expovariate(rate)
    tasks.sort(key=lambda x: x.arrival_time)
    return tasks


def staleness_stress_device(n_tasks: int = 200, seed: int = 42,
                             device_name: str = "RPi5"):
    rng   = random.Random(seed)
    tasks = []
    tid   = 0
    t     = 0.0
    for _ in range(n_tasks):
        if rng.random() < 0.70:
            model = rng.choice(["DistilBERT", "WhisperTiny"])
        else:
            model = rng.choice(["MiDaS", "YOLOv5n"])
        tasks.append(make_device_task(tid, model, t, device_name, rng=rng))
        tid += 1
        t   += rng.expovariate(1 / 0.04)
    tasks.sort(key=lambda x: x.arrival_time)
    return tasks

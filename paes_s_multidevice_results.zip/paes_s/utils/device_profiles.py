"""
Device Hardware Profiles for PAES-S Multi-Device Simulation
============================================================
Each device profile captures the hardware characteristics that affect
AI inference scheduling behaviour:

  - latency_scale:   multiplier on base inference times (relative to i7-1165G7 baseline)
  - arrival_scale:   task arrival rate multiplier (faster devices drain queues faster)
  - cache_kb:        L3 cache size — affects cache-warm bonus magnitude
  - cores:           logical core count (single-threaded sim; affects thermal throttling model)
  - freq_ghz:        max boost frequency
  - mem_bw_gbps:     memory bandwidth — affects memory-bound model latency
  - thermal_factor:  sustained throughput degradation from throttling (1.0 = no throttle)

Latency scaling methodology:
  Base latencies from PAES Table I are measured on i7-1165G7 (scale=1.0).
  Scaling for other devices derived from:
    - Published MLPerf Edge / AI Benchmark results
    - ARM Cortex-A76 vs Intel Tiger Lake single-thread perf ratios
    - Intel Core Ultra 5/9 published AI inference benchmarks
    - Thermal throttling measurements from published reviews

References:
  RPi5 vs laptop inference: github.com/nicholasjclark/rpi-benchmarks
  Core Ultra 9 275H: Intel ARK + Notebookcheck sustained perf data
  Core Ultra 5: Intel optimization guide
"""

DEVICE_PROFILES = {
    "RPi5": {
        "label":            "Raspberry Pi 5 (Cortex-A76, 2.4 GHz, 8 GB)",
        "cores":            4,
        "freq_ghz":         2.4,
        "mem_bw_gbps":      17.0,    # LPDDR4X-4267
        "cache_kb":         512,     # 512 KB L2 per core, shared L3 absent
        "latency_scale":    4.8,     # ~5x slower than i7-1165G7 on CPU inference
        "thermal_factor":   0.82,    # throttles to ~82% under sustained load
        "arrival_scale":    1.0,     # arrival rate unchanged (external sensor)
        "overhead_us":      1.23,    # measured PAES paper RPi5 overhead
        "color":            "#d62728",
        "marker":           "o",
        "notes": (
            "ARM Cortex-A76 is ~4–5x slower than Tiger Lake for float32 DNN inference. "
            "No NPU. Throttles under sustained multi-model load. "
            "This is where scheduling matters most — queue depth is large."
        ),
    },

    "CoreUltra5": {
        "label":            "Intel Core Ultra 5 125H (14 cores, 4.5 GHz, 32 GB)",
        "cores":            14,
        "freq_ghz":         4.5,
        "mem_bw_gbps":      68.3,    # DDR5-5600 dual channel
        "cache_kb":         18432,   # 18 MB L3
        "latency_scale":    0.72,    # ~28% faster than i7-1165G7 (more P-cores, AVX-512)
        "thermal_factor":   0.94,    # mild throttle on sustained load
        "arrival_scale":    1.0,
        "overhead_us":      0.71,    # estimated (faster than i7)
        "color":            "#1f77b4",
        "marker":           "s",
        "notes": (
            "Core Ultra 5 125H: 6P + 8E cores. PAES paper measured strongest results here: "
            "lowest latency (78.96 ms, -7.6% vs FIFO), highest throughput (+8.2%), "
            "lowest queue wait (-28.1%). Heterogeneous core count amplifies scheduling value."
        ),
    },

    "CoreUltra9": {
        "label":            "Intel Core Ultra 9 275H (16 cores, 5.4 GHz, 64 GB)",
        "cores":            16,
        "freq_ghz":         5.4,
        "mem_bw_gbps":      89.6,    # DDR5-5600 quad-channel equivalent
        "cache_kb":         24576,   # 24 MB L3
        "latency_scale":    0.55,    # ~45% faster than i7-1165G7
        "thermal_factor":   0.97,    # excellent cooling headroom
        "arrival_scale":    1.0,
        "overhead_us":      0.65,
        "color":            "#2ca02c",
        "marker":           "^",
        "notes": (
            "High-end platform. PAES paper: all schedulers converge at 0% miss rate "
            "and ~24ms avg latency — hardware drains queue faster than tasks arrive. "
            "Scheduling order has minimal measurable impact. Boundary condition device."
        ),
    },
}

# Reference device (PAES paper baseline — not re-run here but used for normalisation)
REFERENCE_DEVICE = {
    "label":         "Intel i7-1165G7 (4 cores, 4.7 GHz, 16 GB) [PAES baseline]",
    "latency_scale": 1.0,
    "color":         "#7f7f7f",
    "marker":        "D",
}

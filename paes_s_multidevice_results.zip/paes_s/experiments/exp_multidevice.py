"""
Multi-Device Experiment: RPi5 · Core Ultra 5 · Core Ultra 9
=============================================================
Runs all schedulers on all three devices across three workloads.
Produces:
  - Table III : Per-device queue wait + SWQ for all schedulers
  - Figure 5  : Queue wait heatmap (device × scheduler)
  - Figure 6  : SWQ heatmap (device × scheduler)
  - Figure 7  : Per-device staleness decay impact (robot pipeline)
  - Figure 8  : Rank stability plot — does PAES-S rank hold across devices?
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import copy
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
matplotlib.rcParams.update({"font.family": "serif", "font.size": 10})

from schedulers.schedulers import SCHEDULERS, simulate
from utils.metrics import compute_all_metrics, per_model_staleness
from utils.device_profiles import DEVICE_PROFILES
from utils.device_workloads import (
    synthetic_uniform_device,
    robot_pipeline_device,
    staleness_stress_device,
)

N_RUNS = 10

WORKLOADS = {
    "Synthetic":  lambda dev, seed: synthetic_uniform_device(600,  seed, dev),
    "Robot":      lambda dev, seed: robot_pipeline_device(30.0,    seed, dev),
    "Staleness":  lambda dev, seed: staleness_stress_device(200,   seed, dev),
}

DEVICES = list(DEVICE_PROFILES.keys())


# ── Core runner ──────────────────────────────────────────────────────────────

def run_cell(device_name, workload_fn, n_runs=N_RUNS):
    """Run all schedulers on one device × workload cell."""
    results = {name: [] for name in SCHEDULERS}
    for run_i in range(n_runs):
        tasks_template = workload_fn(device_name, seed=run_i * 7 + 13)
        for sched_name, (sched_fn, drop) in SCHEDULERS.items():
            tasks = copy.deepcopy(tasks_template)
            completed, dropped = simulate(tasks, sched_fn, drop_enabled=drop)
            m = compute_all_metrics(completed, dropped)
            results[sched_name].append(m)
    # Aggregate
    agg = {}
    for name, runs in results.items():
        agg[name] = {
            "qw_mean":  np.mean([r["queue_wait_mean_ms"] for r in runs]),
            "qw_std":   np.std( [r["queue_wait_mean_ms"] for r in runs]),
            "swq_mean": np.mean([r["swq"]                for r in runs]),
            "swq_std":  np.std( [r["swq"]                for r in runs]),
            "mr_mean":  np.mean([r["deadline_miss_rate"] for r in runs]),
            "dr_mean":  np.mean([r["drop_rate"]          for r in runs]),
            "e_mean":   np.mean([r["total_energy_mj"]    for r in runs]),
        }
    return agg


# ── Heatmap helper ───────────────────────────────────────────────────────────

def draw_heatmap(matrix, row_labels, col_labels, title, xlabel, cmap, ax,
                 fmt=".0f", annot_suffix="", lower_better=True):
    """Draw annotated heatmap on ax."""
    data = np.array(matrix)
    im   = ax.imshow(data, cmap=cmap, aspect="auto")
    ax.set_xticks(range(len(col_labels)))
    ax.set_xticklabels(col_labels, rotation=30, ha="right", fontsize=9)
    ax.set_yticks(range(len(row_labels)))
    ax.set_yticklabels(row_labels, fontsize=9)
    ax.set_title(title, fontsize=10, pad=6)
    ax.set_xlabel(xlabel, fontsize=9)

    vmin, vmax = data.min(), data.max()
    for i in range(len(row_labels)):
        for j in range(len(col_labels)):
            v = data[i, j]
            # Text colour: white on dark cells
            norm = (v - vmin) / (vmax - vmin + 1e-9)
            txt_col = "white" if (norm > 0.6 if lower_better else norm < 0.4) else "black"
            ax.text(j, i, f"{v:{fmt}}{annot_suffix}",
                    ha="center", va="center", fontsize=7.5,
                    color=txt_col, fontweight="bold")
    return im


# ── Main ─────────────────────────────────────────────────────────────────────

def run(save_dir: str = "results"):
    os.makedirs(save_dir, exist_ok=True)

    # ── Collect all results ──────────────────────────────────────────────
    # all_results[workload][device][scheduler] = agg_dict
    all_results = {}
    for wl_name, wl_fn in WORKLOADS.items():
        all_results[wl_name] = {}
        for dev in DEVICES:
            prof = DEVICE_PROFILES[dev]
            print(f"  Running {wl_name} / {dev} ({N_RUNS} runs) ...", flush=True)
            all_results[wl_name][dev] = run_cell(dev, wl_fn, N_RUNS)

    sched_names = list(SCHEDULERS.keys())

    # ── Table III: per-device detailed results ───────────────────────────
    for wl_name in WORKLOADS:
        print(f"\n{'='*72}")
        print(f"Workload: {wl_name}")
        print(f"{'='*72}")
        print(f"{'Scheduler':<18}", end="")
        for dev in DEVICES:
            print(f"  {dev:^24}", end="")
        print()
        # sub-headers
        print(f"{'':18}", end="")
        for _ in DEVICES:
            print(f"  {'QW(ms)±std':>12}  {'SWQ':>8}", end="")
        print()
        print("-" * (18 + 24 * len(DEVICES)))

        for sch in sched_names:
            print(f"{sch:<18}", end="")
            for dev in DEVICES:
                r = all_results[wl_name][dev][sch]
                qw  = r["qw_mean"]
                qws = r["qw_std"]
                swq = r["swq_mean"]
                print(f"  {qw:>7.0f}±{qws:<5.0f}  {swq:>8.3f}", end="")
            print()

    # ── Figure 5 & 6: Heatmaps (one per workload) ───────────────────────
    for wl_name in WORKLOADS:
        fig, axes = plt.subplots(1, 2, figsize=(14, 4.5))
        fig.suptitle(f"Device × Scheduler Performance — {wl_name} Workload\n"
                     f"(n={N_RUNS} per device)", fontsize=11)

        # QW heatmap
        qw_matrix = [
            [all_results[wl_name][dev][sch]["qw_mean"] for sch in sched_names]
            for dev in DEVICES
        ]
        im1 = draw_heatmap(qw_matrix, DEVICES, sched_names,
                            "Queue Wait (ms) — lower is better",
                            "Scheduler", "YlOrRd", axes[0],
                            fmt=".0f", lower_better=True)
        plt.colorbar(im1, ax=axes[0], shrink=0.8)

        # SWQ heatmap
        swq_matrix = [
            [all_results[wl_name][dev][sch]["swq_mean"] for sch in sched_names]
            for dev in DEVICES
        ]
        im2 = draw_heatmap(swq_matrix, DEVICES, sched_names,
                            "Staleness-Weighted Quality — higher is better",
                            "Scheduler", "YlGn", axes[1],
                            fmt=".3f", lower_better=False)
        plt.colorbar(im2, ax=axes[1], shrink=0.8)

        plt.tight_layout()
        tag  = wl_name.lower()
        path = os.path.join(save_dir, f"fig56_heatmap_{tag}.pdf")
        plt.savefig(path, dpi=150, bbox_inches="tight")
        plt.savefig(path.replace(".pdf", ".png"), dpi=150, bbox_inches="tight")
        plt.close()
        print(f"\n[Device] Saved → {path}")

    # ── Figure 7: Per-device SWQ bar chart (Robot workload) ─────────────
    fig, axes = plt.subplots(1, len(DEVICES), figsize=(5 * len(DEVICES), 5),
                              sharey=False)
    for ax, dev in zip(axes, DEVICES):
        prof   = DEVICE_PROFILES[dev]
        scheds = sched_names
        swq_v  = [all_results["Robot"][dev][s]["swq_mean"] for s in scheds]
        swq_e  = [all_results["Robot"][dev][s]["swq_std"]  for s in scheds]
        colors = ["#d62728" if s == "FIFO" else
                  "#1f77b4" if s == "PAES" else
                  "#2ca02c" if s == "PAES-S" else
                  "#ff7f0e" if s == "PAES-S-Drop" else
                  "#aec7e8" for s in scheds]

        bars = ax.bar(range(len(scheds)), swq_v, color=colors,
                      edgecolor="black", linewidth=0.6)
        ax.errorbar(range(len(scheds)), swq_v, yerr=swq_e,
                    fmt="none", color="black", capsize=3, linewidth=1)
        ax.set_xticks(range(len(scheds)))
        ax.set_xticklabels(scheds, rotation=40, ha="right", fontsize=8)
        ax.set_ylabel("SWQ" if dev == DEVICES[0] else "")
        ax.set_title(f"{dev}\n{prof['freq_ghz']} GHz · {prof['cores']}c",
                     fontsize=9)
        ax.grid(True, alpha=0.3, axis="y")

        # Annotate PAES-S gain over FIFO
        fifo_swq = all_results["Robot"][dev]["FIFO"]["swq_mean"]
        paes_s_swq = all_results["Robot"][dev]["PAES-S"]["swq_mean"]
        gain = (paes_s_swq - fifo_swq) / fifo_swq * 100
        ax.text(0.5, 0.97, f"PAES-S vs FIFO: {gain:+.1f}% SWQ",
                transform=ax.transAxes, ha="center", va="top",
                fontsize=8, color="#2ca02c",
                bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.7))

    fig.suptitle("Figure 7 — SWQ by Scheduler × Device (Robot Pipeline)",
                 fontsize=11)
    plt.tight_layout()
    path = os.path.join(save_dir, "fig7_swq_by_device_robot.pdf")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.savefig(path.replace(".pdf", ".png"), dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[Device] Saved → {path}")

    # ── Figure 8: Rank stability across devices ──────────────────────────
    fig, axes = plt.subplots(1, len(WORKLOADS), figsize=(5 * len(WORKLOADS), 5))
    for ax, wl_name in zip(axes, WORKLOADS):
        # For each device, rank schedulers by SWQ
        dev_ranks = {}
        for dev in DEVICES:
            swq_v = [(s, all_results[wl_name][dev][s]["swq_mean"]) for s in sched_names]
            sorted_scheds = sorted(swq_v, key=lambda x: -x[1])
            dev_ranks[dev] = {s: rank + 1 for rank, (s, _) in enumerate(sorted_scheds)}

        # Plot rank lines
        x = range(len(DEVICES))
        for sch in sched_names:
            ranks  = [dev_ranks[dev][sch] for dev in DEVICES]
            style  = "-" if sch in ("PAES-S", "PAES", "FIFO", "PAES-S-Drop") else "--"
            lw     = 2.0 if sch in ("PAES-S", "PAES-S-Drop") else 1.2
            alpha  = 1.0 if sch in ("PAES-S", "PAES", "FIFO", "PAES-S-Drop") else 0.5
            ax.plot(x, ranks, linestyle=style, linewidth=lw, alpha=alpha,
                    marker="o", markersize=6, label=sch)

        ax.set_xticks(range(len(DEVICES)))
        ax.set_xticklabels(DEVICES, fontsize=9)
        ax.set_yticks(range(1, len(sched_names) + 1))
        ax.set_yticklabels([f"#{i}" for i in range(1, len(sched_names) + 1)], fontsize=8)
        ax.invert_yaxis()
        ax.set_title(f"{wl_name}", fontsize=10)
        ax.set_ylabel("SWQ Rank (1 = best)" if wl_name == list(WORKLOADS.keys())[0] else "")
        ax.grid(True, alpha=0.3)

    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=5, fontsize=8,
               bbox_to_anchor=(0.5, -0.05))
    fig.suptitle("Figure 8 — SWQ Rank Stability Across Devices", fontsize=11)
    plt.tight_layout()
    path = os.path.join(save_dir, "fig8_rank_stability.pdf")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.savefig(path.replace(".pdf", ".png"), dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[Device] Saved → {path}")

    # ── Key numbers summary ──────────────────────────────────────────────
    print("\n" + "="*65)
    print("KEY NUMBERS SUMMARY (Robot Pipeline)")
    print("="*65)
    for dev in DEVICES:
        prof = DEVICE_PROFILES[dev]
        fifo_qw   = all_results["Robot"][dev]["FIFO"]["qw_mean"]
        paes_qw   = all_results["Robot"][dev]["PAES"]["qw_mean"]
        paess_qw  = all_results["Robot"][dev]["PAES-S"]["qw_mean"]
        fifo_swq  = all_results["Robot"][dev]["FIFO"]["swq_mean"]
        paes_swq  = all_results["Robot"][dev]["PAES"]["swq_mean"]
        paess_swq = all_results["Robot"][dev]["PAES-S"]["swq_mean"]

        print(f"\n{dev}  ({prof['label']})")
        print(f"  Queue Wait:  FIFO={fifo_qw:.0f}ms  PAES={paes_qw:.0f}ms  "
              f"PAES-S={paess_qw:.0f}ms")
        print(f"  PAES vs FIFO:   {(fifo_qw-paes_qw)/fifo_qw*100:+.1f}% QW reduction")
        print(f"  PAES-S vs FIFO: {(fifo_qw-paess_qw)/fifo_qw*100:+.1f}% QW reduction")
        print(f"  SWQ:   FIFO={fifo_swq:.3f}  PAES={paes_swq:.3f}  PAES-S={paess_swq:.3f}")
        print(f"  PAES-S SWQ gain vs FIFO:  {(paess_swq-fifo_swq)/fifo_swq*100:+.1f}%")
        print(f"  PAES-S SWQ gain vs PAES:  {(paess_swq-paes_swq)/paes_swq*100:+.1f}%")
        print(f"  {prof['notes'][:90]}")

    return all_results


if __name__ == "__main__":
    run()
